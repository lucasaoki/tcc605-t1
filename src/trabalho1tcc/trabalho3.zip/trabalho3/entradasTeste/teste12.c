int x, x, y;	//declarando duas vezes a mesma variavel.

void main(){
	x = 0;
	y = x + 5;
	if (!x){
		y = y + 1;
	}
}
