void main(){
	x;	//uma declaração sem tipo
	int z=0;
	switch (z){
		case 0:
			x = 5;
			break;
		default:
			x = -2;
			break;
	}		
}
