int true = 1;

void main(){
	int x = 0;
	;	// testando ; sem nada
	if (true){
		x = x + 1;
	} else {
	 	x = 0;
	}
}
