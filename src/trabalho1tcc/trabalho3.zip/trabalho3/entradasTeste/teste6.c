int z, w, _y_;

void main(){
	z = 7;
	switch(z) {
		if (z >= 10) { //usando >=
			break;
			/* nao afeta execucao antes do primeiro case */
		}
		case 2:
			_y_ = z + 2;
			break;
		case 7:
			w = 4;
			break;
	}
}
