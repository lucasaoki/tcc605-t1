int y;

void main(){
	int y;	// re-decalarando variavel. Semantico
	y = 0;
	switch(y){
		case 0:
			y = y + 1;
			break;
		default:
			y = 0;
			break;
	}
}
