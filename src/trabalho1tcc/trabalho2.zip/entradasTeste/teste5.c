int z, w, _y_;

void main(){
	z = 7;
	switch(z) {
		case 2:
			_y_ = z + 2;
			break;
		case 7:
			w = 4;
			break;
		while (z < 10) {
			break;
			/* erro sintatico */
		}
	}
}

