int x, y, z;

//Comentario de linha - Teste

void main(){
	int a = 2, b = 3, c = 4;

	while (z){
		
		switch( x ){
			case 0: break;
			case 1*1+1: break;
			default: 
					y = y + 2;
		} 
	}
}
