int x1, x2;

void main(){
	x1 = 5;
	while (x1 < 10) {
		if (x1 == 8) {
			x2 = 09;
		}
		if (x2 < 10) {
			x2 = 5;
		}
		else {
			x1 = x2;
		}
		else {
			x2 = x1;
		}
		x1 = x1 + 1;
	}
}
