void main() {
	switch (x) {
		case 1:
			x = x + 1;
			// nao declaro variavel - tratamento do erro semantico no trabalho 3
			// deveria ser tratado no analisador semantico
			break;
		case 2:
			x = x - 1;
			break;
		default:
			break;
	}	
}
