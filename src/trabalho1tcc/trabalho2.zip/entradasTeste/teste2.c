int x,y,z;
int banana;
int a = 2,b = 3,c = 4;	// atribuição na declaração

void mmc(int b){	// uso de funções
	int a,b,c;
}

void main(){
	
	int jaca;
	
	if( jaca == 1){
		mmc(banana);
	}	
	else{
		banana = 2;	
	}

}
