int z = 2;

void f(int x) {		//função declarada com um argumento
	x = x + 1;
	y = y + 1;
}

void main(){
	int w = 3;
	f(z, w);	// chamando função com dois parametros
}
