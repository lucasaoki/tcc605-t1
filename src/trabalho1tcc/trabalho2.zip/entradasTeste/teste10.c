int a = 0;
if (a >=0){
	//erro sintatico?
}
void main(){
	int x = 10;
}
