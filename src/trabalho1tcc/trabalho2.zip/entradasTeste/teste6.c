int x=10;

void main(){
	if (x > 10) {
		x = x + 1;
	}
	if (x <= 10 && x >= 0){
		if (x == 10){
			x = x - 1;
		}
	}
	else {
		x = x + 10;
	}
}
