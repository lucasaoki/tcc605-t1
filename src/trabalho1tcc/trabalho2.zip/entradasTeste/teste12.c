void main(){
	int a=1;
	switch(a){
		case 1:
			a = !a;		//usando NOT
			break;
		if (a >=0 || a <=1) {	//com inequação e OR
			a = a + 2;
		}
		if (a == 0 && a >=2) {	// e AND
			a = a - 1;
		}
		default:
			break;
	}
}
