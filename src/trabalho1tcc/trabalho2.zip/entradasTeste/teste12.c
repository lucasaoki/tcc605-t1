void main(){
	int a=1;
	switch(a){
		case 1:
			a = !a;
			break;
		if (a >=0 || a <=1) {
			a = a + 2;
		}
		if (a == 0 && a >=2) {
			a = a - 1;
		}
		default:
			break;
	}
}
