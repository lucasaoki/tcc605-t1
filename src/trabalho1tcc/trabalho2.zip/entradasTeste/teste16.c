void main(){
	switch(x){	/*uso de variavel nao declarada. Semantico!*/
		case 0:
			x = x + 1;
			break;
		case 1:
			x = x + 2;
			break;
		default:
			x = 0;
			break;
	}
}
