int x,y,z;
int banana;
int a = 2,b = 3,c = 4;

//Comentario de linha - Teste

void main(){
	
	/*
		Comentario de Bloco
		um pequeno teste para mostrar que funciona
	*/

	while (z){
		
		switch( x ){
			case 0: break;
			case 1*1+1: break;	// uso de expressao constante no case
			default: 
					y = y + 2;
		} 
	}
}
