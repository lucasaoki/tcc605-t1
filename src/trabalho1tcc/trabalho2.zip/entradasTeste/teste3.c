int x,y,z;
int 1234jaca____;	// variavel começando com numero?? 
int a = 2,b = 3,c = 4;

void main(){
	
	while (z){
		
		switch( x ){
			case 0: break;
			case 1*1+1: break;
			default: 
					y = y + 2;
		} 
	}
}
