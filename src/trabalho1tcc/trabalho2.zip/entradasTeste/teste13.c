void main(){
	int x = 0;
	while (x < 10) {
		x = x + 1;
		if (x == 8 || x == 7) {
			break;
		}
	}
}
