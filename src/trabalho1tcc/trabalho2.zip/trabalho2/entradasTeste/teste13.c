int false = 0;

void main(){
	int x	//esquecendo o ;
	while (!false) {
		x = 20;
	}
}
