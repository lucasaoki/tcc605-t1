Encontrou " <NUMBER> "1234 "" na linha2, coluna 5.
Espera-se:
    <IDENT> ...
    
