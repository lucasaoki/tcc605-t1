Encontrou " "," ", "" na linha1, coluna 13.
Espera-se:
    ")" ...
    
