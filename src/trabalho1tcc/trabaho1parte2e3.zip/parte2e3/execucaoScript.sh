#!/bin/bash

output_files=./saidas/
input_files=./entradasTeste/
exec_files=./executaveis/

for i in `seq 1 4`; do
	java -cp ${exec_files} Switch < ${input_files}teste$i.c > ${output_files}saida$i.txt
done

