@(1,1)	INT	-	int
@(1,5)	IDENT	-	x
@(1,6)	COMMA	-	,
@(1,7)	IDENT	-	y
@(1,8)	COMMA	-	,
@(1,9)	IDENT	-	z
@(1,10)	SEMICOL	-	;
@(2,1)	INT	-	int
Encountered " <NUMBER> "1234 "" at line 2, column 5.
Was expecting:
    <IDENT> ...
    
