int x,y,z;
int banana;
int a = 2,b = 3,c = 4;

void mmc(int b){
	int a,b,c;
}

void main(){
	
	int jaca;
	
	if( jaca == 1){
		mmc(banana);
	}	
	else{
		banana = 2;	
	}

}
