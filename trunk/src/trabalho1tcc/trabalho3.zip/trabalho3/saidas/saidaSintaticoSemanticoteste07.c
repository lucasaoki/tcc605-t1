jaca id nao foi declarado
procedimento nao definido

0
int 0 32 tipo null 0 0 null 0 0
TRUE 0 32 const null 1 0 null 0 0
FALSE 0 32 const null 0 0 null 0 0
readlong 0 0 proc null 0 -1 null 0 0
writelong 0 0 proc null 0 -1 null 0 0
writeline 0 0 proc null 0 -1 null 0 0
x 0 0 var int 0 0 null 0 0
main 0 0 proc null 0 0 null 0 0

SUCESSO
