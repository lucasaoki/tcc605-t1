/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package semantico;

/**
 *
 * @author gilvolpe
 */
public interface Constantes {
    public static final int BYTES_INT = 4;
    public static final String CONSTANTE = "const"; 
}
