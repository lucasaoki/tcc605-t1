/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package semantico;

/**
 *
 * @author gilvolpe
 */
public interface Constantes {
    public static final int BYTES_INT = Integer.SIZE;
    public static final String CONSTANTE = "const"; 
    public static final String VAR = "var";
    public static final String TYPE = "tipo";
    public static final String INT = "int";
    public static final String PARAM = "param";
    public static final String PROC = "proc";
}
