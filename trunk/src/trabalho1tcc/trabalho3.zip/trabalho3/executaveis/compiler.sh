#!/bin/bash

javac -cp ../codigo-fonte/ -d . ../codigo-fonte/*.java
