int x;

void gcd(int x,int y){
	x = y;
}

void jaca(int x){

	switch(x){
		case 0:
			writelong(0);	
			break;
		case 1:
			break;	
		case 1*2-1:
			break;
		default:
	}

	
}

void main(){
	x = 2 ;
	gcd(x,2);
}
