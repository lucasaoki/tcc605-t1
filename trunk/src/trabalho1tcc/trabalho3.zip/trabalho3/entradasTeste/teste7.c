int z, w, _y_;

void main(){
	z = 7;
	switch(z) {
		case 2:
			_y_ = z + 2;
			break;
		if (z < 10 || z > 10) {	 //usando OR, > e <
			break;
			/* agora afeta a execucao */
		}
		case 7:
			w = 4;
			break;
	}
}
