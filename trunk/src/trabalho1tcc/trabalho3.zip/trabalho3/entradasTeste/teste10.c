void main(){
	int x = 0;
	while (x < 10) {
		x = x + 1;
		else {
			// um else sem um if!!
		}
	}
}
