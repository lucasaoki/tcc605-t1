//9
void main(){
	x = 0; //x nao declarado
	while (x < 10) {
		x = x + 1;
	}
}
