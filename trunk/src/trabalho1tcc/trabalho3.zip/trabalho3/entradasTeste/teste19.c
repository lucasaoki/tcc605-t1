int x=4;

void main(){
	int y;
	y = ((2*x) - 5) + 3*(x+2)); //parenteses final a mais
}
