//novo
int x;
void main(){
	 x = 2;	
	jaca(x);
}
