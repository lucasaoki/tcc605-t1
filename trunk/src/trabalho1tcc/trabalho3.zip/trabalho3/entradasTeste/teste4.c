int x1, x2;

void main(){
	x1 = 5;
	while (x1 <= 10) {
		if (x1 != 8) {	//usando !=
			x2 = 09;
		}
		if (x2 < 10) {	//usando <
			x2 = 5;
		}
		else {			//else associado ao ultimo if
			x1 = x2;
		}
		else {			//e esse else?
			x2 = x1;
		}
		x1 = x1 + 1;
	}
}
