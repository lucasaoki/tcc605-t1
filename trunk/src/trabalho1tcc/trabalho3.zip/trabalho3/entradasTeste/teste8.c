int a = 0;
if (a >=0){
	//só posso declarar variaveis e funções aqui!!
}
void main(){
	int x = 10;
}
