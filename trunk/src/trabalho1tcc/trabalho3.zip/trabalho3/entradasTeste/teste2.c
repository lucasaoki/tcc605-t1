int x,y;	// declarando variaveis
int Z;
int a = 2, b = 3;	// atribuição na declaração

void mmc(int b){	// uso de funções
	b = 4*b;	// multiplicação
}

void main(){
	int w;
	if( b == 1){	//usando if e ==
		mmc(a);	//chamada de função
	}	
	else {		//usando else
		x = !a;	//usando NOT
		y = 1 + x; //usando soma
		Z = b/5 - 1; // divisao e subtração
		w = a%2;  //usando %
	}

}
