int x,y,z;
int banana;
int a = 2,b = 3,c = 4;

//Comentario de linha - Teste

void main(){
	
	/*
		Comentario de Bloco
		um pequeno teste para mostrar que funciona
	*/

	while (z){	//usando while
		
		switch( x ){	//usando switch
			case 0: break;	//usando case e break
			case 1*1+1: break;	// uso de expressao constante no case
			default: //usando default
					y = y + 2;
		} 
	}
}
