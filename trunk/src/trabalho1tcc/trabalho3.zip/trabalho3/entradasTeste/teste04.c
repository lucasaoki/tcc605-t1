//18

void f(int x, int y){ //declarando função com dois argumentos
	x = 2*y;
}

void main(){
	f(4); //passando apenas um argumento para a função
}
