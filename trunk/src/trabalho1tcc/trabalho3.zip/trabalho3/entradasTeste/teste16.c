int y = 2;

int g(int x){	//declarando função como int
	x = x + 1;
}

void main(){
	g(y);
}
