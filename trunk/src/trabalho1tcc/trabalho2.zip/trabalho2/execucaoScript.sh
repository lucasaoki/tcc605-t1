#!/bin/bash

exec_files=./executaveis/
output_files=./saidas/

echo "Script para testar o analisador léxico do programa"
echo "As pastas/arquivos existentes são:"

ls --color=auto


echo "Entre com a pasta contendo os arquivos testes"
read input_dir

echo "Execucao somente do analisador léxico sintático" 
for i in `ls ${input_dir}`; do
	java -cp ${exec_files} Switch 2 < $input_dir/$i > ${output_files}saidaLexicoSintatico$i
done
